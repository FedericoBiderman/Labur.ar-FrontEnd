export const users = [
    {
        id: 1,
        name: "Luciana Julia",
        location: "Portland Illinois",
        distance: 11,
        age: 23,
        image: require("https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcT5ZCXhOz-XJHK0qh8QbH2971MCUDC5c2rPvQ&s")
    },
    {
        id: 2,
        name: "Tracy Fradera",
        location: "Portland Illinois",
        distance: 11,
        age: 24,
        image: require("https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSibQVWsGEdNuWzffJeJ-AuKGcYKe-GH7aMxg&s")
    }
]