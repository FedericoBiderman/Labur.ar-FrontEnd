import React, { useEffect, useState } from 'react';
import {View} from 'react-native';
import { StatusBar } from 'expo-status-bar';
import {users as usersArray} from './utils/data.js';
import Card from './components/Card.js';
import Footer from './components/Footer.js';
export default function App() {
  const [users, setUsers] = useState(usersArray);

  useEffect(()=>{
    if(!users.length){
      setUsers(users);
    }
  },[users.length])
  return(
    <View style={{flex: 1, alignItems: "center", backgroundColor: "white"}}>
      <StatusBar hidden={true} />
      {
        users.map(({name, image, location, distance, age}, index)=>{
          const isFirst = index == 0;
          return (
            <Card
            key={name}
            name={name}
            location={location}
            distance={distance}
            age={age}
            image={image}
            isFirst={isFirst}
            />
          )
        }).reverse()
      }
      <Footer/>
    </View>
  )
};